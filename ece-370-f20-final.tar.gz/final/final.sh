rosservice call gazebo/delete_model final_setup
rosrun gazebo_ros spawn_model -file final.sdf -sdf -model final_setup -y -0.0 -x -0.0 -z 0.0